﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double hr, vh, pd, td, sb, sl;
            hr = Convert.ToDouble(txtHrTrab.Text);
            vh = Convert.ToDouble(txtValHr.Text);
            pd = Convert.ToDouble(txtPerDesc.Text);

            sb = hr * vh;

            td = (pd / 100) * sb;

            sl = sb - td;

            lblResult.Text = Convert.ToString(sl);

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtHrTrab.Clear();
            txtPerDesc.Clear();
            txtValHr.Clear();
            txtHrTrab.Focus();
        }
    }
}
